import gzip
import html
import shutil
import tarfile
import zipfile
import requests
import argparse
from tqdm import tqdm
import random
import os
import h5py
import numpy as np
import glob
from torch.utils.data import Dataset
import json
from plyfile import PlyData, PlyElement
import torch
from tqdm import tqdm
import sys
from datetime import datetime
from dataset import pointfly as pf
import scipy.spatial.distance
from sklearn.model_selection import train_test_split
from transforms_3d import *
import argparse
import math
import os
from datetime import datetime

import h5py
import numpy as np
import plyfile
from matplotlib import cm


def prepare_data(partition, path):
    data_dir = path
    parser = argparse.ArgumentParser()
    #parser.add_argument('-d', '--data', dest='data_dir', default=default_data_dir,
                        #help=f'Path to S3DIS data (default is {default_data_dir})')
    #parser.add_argument('-f', '--folder', dest='output_dir', default=default_output_dir,
                        #help=f'Folder to write labels (default is {default_output_dir})')
    parser.add_argument('--max_num_points', '-m', help='Max point number of each sample', type=int, default=8192)
    parser.add_argument('--block_size', '-b', help='Block size', type=float, default=1.5)
    parser.add_argument('--grid_size', '-g', help='Grid size', type=float, default=0.03)
    parser.add_argument('--save_ply', '-s', help='Convert .pts to .ply', action='store_true')

    args = parser.parse_args()
    print(args)
    
    # Set Hyperparameters
    
    max_num_points = args.max_num_points
    pts_nums = []
    total = 0
    batch_size = 2048 # not training batch size rather a dataloader preprocesing bs
    stacked_data = np.zeros((1, max_num_points, 9)) #all the blocks are stacked one after another into this, 1st entry is empty,later deleted
    stacked_label_seg = np.zeros((1, max_num_points), dtype=np.int32) #same logic as above
    
    data = np.zeros((batch_size, max_num_points, 9))
    data_num = np.zeros(batch_size, dtype=np.int32)
    label = np.zeros(batch_size, dtype=np.int32)
    label_seg = np.zeros((batch_size, max_num_points), dtype=np.int32)
    indices_split_to_full = np.zeros((batch_size, max_num_points), dtype=np.int32)
    
    object_dict = {
        'clutter': 0,
        'ceiling': 1,
        'floor': 2,
        'wall': 3,
        'beam': 4,
        'column': 5,
        'door': 6,
        'window': 7,
        'table': 8,
        'chair': 9,
        'sofa': 10,
        'bookcase': 11,
        'board': 12
    }

    for area in os.listdir(data_dir): #traverse each area inside the passed dir e.g. Area_1, Area_2
        path_area = os.path.join(data_dir, area)
        if not os.path.isdir(path_area):
            continue

        path_dir_rooms = os.listdir(path_area)
        for room in path_dir_rooms: # traverse each room inside an area e.g., office_1, office_2
            
            path_annotations = os.path.join(data_dir, area, room, 'Annotations')
            if not os.path.isdir(path_annotations):
                continue

            xyz_room = np.zeros((1, 6))
            label_room = np.zeros((1, 1))

            path_objects = os.listdir(path_annotations)
            for obj in path_objects: # traverse each object inside the annotatios subfolder e.g., beam,chair,ceiling etc
                object_key = obj.split('_', 1)[0] #assign the label id
                try:
                    val = object_dict[object_key]
                except KeyError:
                    continue
                print(f'{room}/{obj[:-4]}')
                xyz_object_path = os.path.join(path_annotations, obj)
                try:
                    xyz_object = np.loadtxt(xyz_object_path)[:, :]  # (N,6)
                except ValueError as e:
                    print(f'ERROR: cannot load {xyz_object_path}: {e}')
                    continue
                label_object = np.tile(val, (xyz_object.shape[0], 1))  # (N,1)
                xyz_room = np.vstack((xyz_room, xyz_object)) # stacking all the objs inside a room makes up the main .txt, this is why the main txt is never
                # read but still all the points inside a room is stacked into these vars
                label_room = np.vstack((label_room, label_object))

            xyz_room = np.delete(xyz_room, [0], 0) # 888k,6 | first entry was empty and hence deleted
            label_room = np.delete(label_room, [0], 0) #888k,1
            
            
            xyzrgb = xyz_room
            labels = label_room
            del xyz_room
            del label_room
            
            xyzrgb[:, 0:3] -= np.amin(xyzrgb, axis=0)[0:3] # Everything now in [0,N] rather eg [-15,-21] or [33,36]
            labels = labels.astype(int).flatten()

            xyz, rgb = np.split(xyzrgb, [3], axis=-1)
            xyz_min = np.amin(xyz, axis=0, keepdims=True)
            xyz_max = np.amax(xyz, axis=0, keepdims=True)
            xyz_center = (xyz_min + xyz_max) / 2
            xyz_center[0][-1] = xyz_min[0][-1]
            # Remark: Don't do global alignment.
            # xyz = xyz - xyz_center
            rgb = rgb / 255.0
            max_room_x = np.max(xyz[:, 0])
            max_room_y = np.max(xyz[:, 1])
            max_room_z = np.max(xyz[:, 2])

            offsets = [('zero', 0.0), ('half', args.block_size / 2)]
            for offset_name, offset in offsets:
                idx_h5 = 0
                idx = 0

                print(f'{datetime.now()}-Computing block id of {xyzrgb.shape[0]} points...')
                xyz_min = np.amin(xyz, axis=0, keepdims=True) - offset
                xyz_max = np.amax(xyz, axis=0, keepdims=True)
                block_size = (args.block_size, args.block_size, 2 * (xyz_max[0, -1] - xyz_min[0, -1]))
                # Note: Don't split over z axis.
                xyz_blocks = np.floor((xyz - xyz_min) / block_size).astype(np.int)

                print(f'{datetime.now()}-Collecting points belong to each block...')
                blocks, point_block_indices, block_point_counts = np.unique(xyz_blocks, return_inverse=True,
                                                                            return_counts=True, axis=0)
                block_point_indices = np.split(np.argsort(point_block_indices), np.cumsum(block_point_counts[:-1]))
                #print(f'{datetime.now()}-{dataset} is split into {blocks.shape[0]} blocks.')

                block_to_block_idx_map = dict()
                for block_idx in range(blocks.shape[0]):
                    block = (blocks[block_idx][0], blocks[block_idx][1])
                    block_to_block_idx_map[(block[0], block[1])] = block_idx

                # merge small blocks into one of their big neighbors
                block_point_count_threshold = max_num_points/10
                nbr_block_offsets = [(0, 1), (1, 0), (0, -1), (-1, 0), (-1, 1), (1, 1), (1, -1), (-1, -1)]
                block_merge_count = 0
                for block_idx in range(blocks.shape[0]):
                    if block_point_counts[block_idx] >= block_point_count_threshold:
                        continue

                    block = (blocks[block_idx][0], blocks[block_idx][1])
                    for x, y in nbr_block_offsets:
                        nbr_block = (block[0] + x, block[1] + y)
                        if nbr_block not in block_to_block_idx_map:
                            continue

                        nbr_block_idx = block_to_block_idx_map[nbr_block]
                        if block_point_counts[nbr_block_idx] < block_point_count_threshold:
                            continue

                        block_point_indices[nbr_block_idx] = np.concatenate(
                            [block_point_indices[nbr_block_idx], block_point_indices[block_idx]], axis=-1)
                        block_point_indices[block_idx] = np.array([], dtype=np.int)
                        block_merge_count = block_merge_count + 1
                        break
                print(f'{datetime.now()}-{block_merge_count} of {blocks.shape[0]} blocks are merged.')

                idx_last_non_empty_block = 0
                for block_idx in reversed(range(blocks.shape[0])):
                    if block_point_indices[block_idx].shape[0] != 0:
                        idx_last_non_empty_block = block_idx
                        break

                # uniformly sample each block
                for block_idx in range(idx_last_non_empty_block + 1):
                    point_indices = block_point_indices[block_idx]
                    if point_indices.shape[0] == 0:
                        continue
                    block_points = xyz[point_indices]
                    block_min = np.amin(block_points, axis=0, keepdims=True)
                    xyz_grids = np.floor((block_points - block_min) / args.grid_size).astype(np.int)
                    grids, point_grid_indices, grid_point_counts = np.unique(xyz_grids, return_inverse=True,
                                                                             return_counts=True, axis=0)
                    grid_point_indices = np.split(np.argsort(point_grid_indices), np.cumsum(grid_point_counts[:-1]))
                    grid_point_count_avg = int(np.average(grid_point_counts))
                    point_indices_repeated = []
                    for grid_idx in range(grids.shape[0]):
                        point_indices_in_block = grid_point_indices[grid_idx]
                        repeat_num = math.ceil(grid_point_count_avg / point_indices_in_block.shape[0])
                        if repeat_num > 1:
                            point_indices_in_block = np.repeat(point_indices_in_block, repeat_num)
                            np.random.shuffle(point_indices_in_block)
                            point_indices_in_block = point_indices_in_block[:grid_point_count_avg]
                        point_indices_repeated.extend(list(point_indices[point_indices_in_block]))
                    block_point_indices[block_idx] = np.array(point_indices_repeated)
                    block_point_counts[block_idx] = len(point_indices_repeated)

                for block_idx in range(idx_last_non_empty_block + 1):
                    point_indices = block_point_indices[block_idx]
                    if point_indices.shape[0] == 0:
                        continue

                    block_point_num = point_indices.shape[0]
                    block_split_num = int(math.ceil(block_point_num * 1.0 / max_num_points))
                    point_num_avg = int(math.ceil(block_point_num * 1.0 / block_split_num))
                    point_nums = [point_num_avg] * block_split_num
                    point_nums[-1] = block_point_num - (point_num_avg * (block_split_num - 1))
                    starts = [0] + list(np.cumsum(point_nums))

                    # Modified following convensions of PointNet.
                    np.random.shuffle(point_indices)
                    block_points = xyz[point_indices]
                    block_rgb = rgb[point_indices]
                    block_labels = labels[point_indices]
                    x, y, z = np.split(block_points, (1, 2), axis=-1)
                    norm_x = x / max_room_x
                    norm_y = y / max_room_y
                    norm_z = z / max_room_z
                    
                    minx = np.min(x)
                    print(minx)
                    miny = np.min(y)
                    x = x - (minx + args.block_size / 2) #Everything squashed into [-.75, +.75] = 1.5 meter during training
                    y = y - (miny + args.block_size / 2)
                    
                    
                    # for every room, 2 offsets thats y office_1 has 127+131 entries in stacked data
                    # max points impact total no.of blocks
                    # total entries are way more than unique blocks. lots of overlap blocks to hve diversity
                    block_xyzrgb = np.concatenate([x, y, z, block_rgb, norm_x, norm_y, norm_z], axis=-1)
                    for block_split_idx in range(block_split_num):
                        start = starts[block_split_idx]
                        point_num = point_nums[block_split_idx]
                        end = start + point_num
                        idx_in_batch = idx % batch_size
                        data[idx_in_batch, 0:point_num, ...] = block_xyzrgb[start:end, :]
                        data_num[idx_in_batch] = point_num
                        #label[idx_in_batch] = dataset_idx  # won't be used...
                        label_seg[idx_in_batch, 0:point_num] = block_labels[start:end]
                        indices_split_to_full[idx_in_batch, 0:point_num] = point_indices[start:end]
                        idx = idx + 1
                        if ((idx + 1) % batch_size == 0) or \
                                (block_idx == idx_last_non_empty_block and block_split_idx == block_split_num - 1):
                                    item_num = idx_in_batch + 1 
                                    stacked_data = np.vstack((stacked_data, data[0:item_num, ...]))
                                    #stacked_data = stacked_data[1:(item_num + 1),...]
                                    stacked_label_seg= np.vstack((stacked_label_seg, label_seg[0:item_num, ...]))
                                    total = total + item_num
                                    #stacked_label_seg = stacked_label_seg[1:(item_num + 1),...]
                    
    for u in  stacked_label_seg.astype(np.int64):
        pts_nums.append(2048)
                                                        
    a = np.array(stacked_data[1:total,...],dtype=np.float32)
    b = np.array(pts_nums[1:total]).reshape(-1)     
    c = np.array(stacked_label_seg[1:total,...],dtype=np.int64)
    del stacked_data
    del data
    
    return (a, None, b, c, None)



################## Main Data Loader (all h5 loaded at once into self.points)  ###########
class S3DIS(Dataset):
    def __init__(self, partition='train',transforms=None, path = None):
        super().__init__()
     
        self.points, _, self.point_nums, self.labels_seg, _  = prepare_data(partition,path)
      
        self.points=pf.global_norm(self.points)
        #np.save('./1',self.points) # check memory usage
        print(self.points.shape)
        print(self.labels_seg.shape)

      
    def __getitem__(self, index):
        
        return self.points[index], self.labels_seg[index], self.point_nums[index],-1
        

    def __len__(self):
        return self.points.shape[0]



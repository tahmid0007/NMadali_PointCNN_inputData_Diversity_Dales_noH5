import torch
from data_class import S3DIS
from torch.utils.data.dataloader import DataLoader
import config
import numpy as np
from run import create_model,calculate_shape_IoU,plot_conf_matrix
import plotly.graph_objects as go
import os
import torch.nn as nn
import util.meter as meter
import sklearn.metrics as metrics
import argparse
     
cats = ['clutter','ceiling','floor','wall','beam','column','door','window','table','chair','sofa','bookcase','board']

config.process = "TEST"
batch = 1
criterion = nn.CrossEntropyLoss()
def main():
    # Let the cmd params dictate which model to load and what test set to use
    pretrained_path = './model.pt'
    TEST_FILE_PATH = 'C:\\Users\\mthossain\\OneDrive - Federation University Australia\\Desktop\\soft study\\Euclideon\\0 Code Base\\NMadali_PointCNN\\train_files.txt'

    parser = argparse.ArgumentParser()
    parser.add_argument('-ts', '--test_file_path', default=TEST_FILE_PATH)
    parser.add_argument('-pre', '--pretrained_model_path', default=pretrained_path)
    parser.add_argument('-cm', '--confusion_matrix', type = int, default=1)

    args = parser.parse_args()
    TEST_FILE_PATH = args.test_file_path
    pretrained_path = args.pretrained_model_path
    confusion_matrix =  args.confusion_matrix
    
    
    net = create_model(config.base_model).to(config.device)
    valid_set = S3DIS(partition='test', path = TEST_FILE_PATH) # partition is ornamental
    valid_loader = DataLoader(valid_set, batch_size=batch, shuffle=False,
                                  num_workers=config.num_workers,  drop_last=False)
    
    checkpoint = torch.load(pretrained_path,'cpu')
    net.load_state_dict(checkpoint['best_model_dict']['acc'])
    net.to(config.device)
    evalu(valid_loader, net,html_path="test_output", calc_confusion_matrix = confusion_matrix)

def evalu(data_loader, net, calc_confusion_matrix=1, rtn_features=False,html_path="test_output"):
    net.eval()
    num_classes = 13
    # Core eval metrics. 
    # this meter thing enables automatic avg when a new item added, its different from list
    precision = meter.AverageValueMeter()
    recall = meter.AverageValueMeter()    
    confusion_matrix_meter = meter.ConfusionMeter(num_classes, normalized=True)
    
    loss_meter = meter.AverageValueMeter()
    acc_meter = meter.ClassErrorMeter(topk=[1, 5], accuracy=True)
    avg_acc_meter = meter.AverageValueMeter()
    Iou_meter = meter.AverageValueMeter()
    Iou_meter = meter.AverageValueMeter()
       
    '''N=len(data_loader.dataset)
    n_sample=int(0.05*len(data_loader.dataset))
    idx_samples=set(np.random.choice(np.arange(N), size=n_sample, replace=False))'''
                
    for i, sample in enumerate(data_loader):
        batch_data=sample[0]
        batch_labels=sample[1]
        '''tmp_set=set(np.arange(batch*i,(batch*i)+batch_data.size(0)))
        tmp_set=list(idx_samples.intersection(tmp_set))'''
        batch_data = batch_data.to(config.device) 
        batch_labels = batch_labels.to(config.device)
        
        raw_out = net.forward(batch_data) 
        pred_choice = raw_out.data.max(2)[1]
        
        ########## THis part is only for block wise visual fig output writing ######################
        
        '''xyz_points=batch_data.cpu().numpy()  
        if xyz_points.shape[-1] > 3:
            xyz_points=xyz_points[:,:,:3]
        seg_label_pred=pred_choice.cpu().numpy()  
        seg_label_gt=batch_labels.cpu().numpy()  
        if len(tmp_set) >0 :
            all_idx=[u- batch*(u//batch) for u in  tmp_set]
            for kk,idx in enumerate(all_idx):
    
                ######################################## FIGURES  ###########################################
                x,y,z=xyz_points[idx].T
                rgb=seg_label_gt[idx]
                fig = go.Figure(data=[go.Scatter3d( x=x, y=y, z=z, mode='markers', marker=dict( size=2, color=rgb, colorscale='Viridis', opacity=0.8 ) )])
                fig.write_html(os.path.join(html_path,"file"+str(tmp_set[kk])+"_gt.html"))
                                    
                x,y,z=xyz_points[idx].T
                rgb=seg_label_pred[idx]
    
                fig = go.Figure(data=[go.Scatter3d( x=x, y=y, z=z, mode='markers', marker=dict( size=2, color=rgb, colorscale='Viridis', opacity=0.8 ) )])
                fig.write_html(os.path.join(html_path,"file"+str(tmp_set[kk])+"_pred.html"))'''
    
        raw_out = raw_out.view(-1, raw_out.shape[-1])
        loss=criterion(raw_out, batch_labels.view(-1).long())

        # for each sample, add the metric into the vars
        # note that add is a special method that auto averages the list entries so far
        # THis is why extracting the 1st entry while printing gives the grand avg
        # the 2nd entry is std 
        loss_meter.add(loss.item())
        acc_meter.add(raw_out.detach(),  batch_labels.view(-1).long().detach())        
        seg_np = batch_labels.cpu().numpy()                
        pred_np = pred_choice.detach().cpu().numpy()        
        ########## Precision and Recall ################################
        # metrics is from sklearn and has a lot of eval metric support including prec/recall/F1 etc
        #report = metrics.classification_report(seg_np.reshape(-1), pred_np.reshape(-1))
        stat_type = 'macro' #micro
        prec,rec,_,_ = metrics.precision_recall_fscore_support(seg_np.reshape(-1), pred_np.reshape(-1), average = stat_type)
        precision.add(prec)
        recall.add(rec)
        with torch.no_grad():
            confusion_matrix_meter.add(raw_out, target=batch_labels)
        ###############################################################
        
        avg_acc_meter.add( metrics.balanced_accuracy_score(seg_np.reshape(-1), pred_np.reshape(-1)))
        Iou_meter.add(np.mean(calculate_shape_IoU(pred_np, seg_np, None)))
        
    avg_precision = precision.value()[0]
    #std_avg_precision = precision.value()[1]
    avg_recall = recall.value()[0]
    #std_avg_recall = recall.value()[1]    
    val_acc = acc_meter.value(1) # name only train ashole val
    avg_per_class_acc = avg_acc_meter.value()[0]
    IOU = Iou_meter.value()[0]    
    
    outstr = '[ Validation summary ] avg_precision: %.6f, avg_recall: %.6f, validation_acc: %.6f, avg_per_class_acc: %.6f, val_ious: %.6f' % (avg_precision ,avg_recall, val_acc, avg_per_class_acc, np.mean(IOU))
    print(outstr)
    
    rst = avg_precision,avg_recall, val_acc,avg_per_class_acc, np.mean(IOU) 
    if calc_confusion_matrix:
        with torch.no_grad():       
            conf_matrix = confusion_matrix_meter.value()
            plot_conf_matrix(cats, conf_matrix,
                                    save_file='{}conf_matrix.pdf'.format(config.result_sub_folder))
        
    else:
        print('skipping confusion matrix')
        
    return rst
                    
if __name__ == '__main__':
    main()
